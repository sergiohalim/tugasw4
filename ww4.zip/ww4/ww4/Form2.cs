﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ww4
{
    public partial class Form2 : Form
    {
        public static Form2 instance;
        public Label lab1;
        public Label labl3;
        

        public Form2()
        {
            InitializeComponent();
            instance = this;
            lab1 = label1;
            labl3 = label3;
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool check = false;
            Form1 form1 = new Form1();
            if (checkBox1.Checked && checkBox2.Checked)
            {
                if (radioButton1.Checked)
                {
                    form1.BackColor = Color.Red;
                }
                else if (radioButton2.Checked)
                {
                    form1.BackColor = Color.Blue;
                }
                else if (radioButton3.Checked)
                {
                    form1.BackColor = Color.Green;
                }
                else if (radioButton4.Checked)
                {
                    form1.BackColor = Color.Black;
                }
                else if (radioButton5.Checked)
                {
                    form1.BackColor = Color.Yellow;    
                }
                 if (radioButton6.Checked)
                {
                    form1.ForeColor = Color.Pink;  
                }
                else if (radioButton7.Checked)
                {
                    form1.ForeColor = Color.Purple;    
                }
                else if (radioButton8.Checked)
                {
                    form1.ForeColor = Color.White;
                }

                

            }
            form1.Show();



        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true && checkBox2.Checked == true)
            {
                button1.Enabled=true;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true && checkBox2.Checked == true)
            {
                button1.Enabled = true;
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
